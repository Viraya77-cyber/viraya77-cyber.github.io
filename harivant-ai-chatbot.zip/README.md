# Harivant AI

A production-ready ChatGPT clone with a beautiful dark-themed interface, built with React and Python.

![Harivant AI](https://img.shields.io/badge/Status-Production%20Ready-green)
![License](https://img.shields.io/badge/License-MIT-blue)

## Features

- **ChatGPT-Style Interface**: Dark theme with smooth animations and professional design
- **Real-time Chat**: Powered by AI models (Groq, OpenAI, or compatible APIs)
- **Chat History**: Persistent chat storage using localStorage
- **Fully Responsive**: Works seamlessly on mobile and desktop
- **PWA Support**: Install as a native app on any device
- **Offline Support**: Service worker provides offline capabilities
- **Multi-line Input**: Shift+Enter for new lines, Enter to send
- **Typing Animation**: Real-time typing indicators for AI responses
- **Auto-scroll**: Automatically scrolls to the latest message

## Tech Stack

### Frontend
- **React 18** - UI library
- **Vite** - Build tool and dev server
- **CSS3** - Styling with CSS variables

### Backend
- **Python 3.9+** - Backend runtime
- **Flask** - Web framework
- **Flask-CORS** - Cross-origin support
- **Requests** - HTTP client for API calls

## Project Structure

\`\`\`
harivant-ai/
├── frontend/                # React frontend
│   ├── public/
│   │   ├── icon-192.png    # PWA icon
│   │   ├── icon-512.png    # PWA icon
│   │   ├── manifest.json   # PWA manifest
│   │   └── sw.js           # Service worker
│   ├── src/
│   │   ├── components/     # React components
│   │   │   ├── ChatArea.jsx
│   │   │   ├── InputBar.jsx
│   │   │   ├── Message.jsx
│   │   │   └── Sidebar.jsx
│   │   ├── context/
│   │   │   └── ChatContext.jsx
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── styles.css
│   ├── package.json
│   └── vite.config.js
│
├── backend/                # Python backend
│   ├── server.py          # Flask API server
│   ├── requirements.txt   # Python dependencies
│   ├── .env.example       # Environment variables template
│   └── .gitignore
│
└── README.md              # This file
\`\`\`

## Installation & Setup

### Prerequisites

- **Node.js** 16+ and npm
- **Python** 3.9+
- **API Key** from Groq, OpenAI, or compatible provider

### Step 1: Get Your API Key

#### Option A: Groq (Recommended - Fast & Free)

1. Visit [https://console.groq.com/keys](https://console.groq.com/keys)
2. Sign up for a free account
3. Create a new API key
4. Copy the API key

#### Option B: OpenAI

1. Visit [https://platform.openai.com/api-keys](https://platform.openai.com/api-keys)
2. Sign in to your account
3. Create a new API key
4. Copy the API key

### Step 2: Setup Backend

\`\`\`bash
# Navigate to backend directory
cd backend

# Create virtual environment (recommended)
python -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Create .env file from example
cp .env.example .env

# Edit .env file and add your API credentials
# Use your favorite text editor (nano, vim, notepad, etc.)
nano .env
\`\`\`

**Edit the `.env` file:**

For **Groq** (recommended):
\`\`\`env
LLM_API_URL=https://api.groq.com/openai/v1/chat/completions
LLM_API_KEY=your_groq_api_key_here
LLM_MODEL=llama-3.3-70b-versatile
\`\`\`

For **OpenAI**:
\`\`\`env
LLM_API_URL=https://api.openai.com/v1/chat/completions
LLM_API_KEY=your_openai_api_key_here
LLM_MODEL=gpt-3.5-turbo
\`\`\`

### Step 3: Setup Frontend

Open a **new terminal window** (keep the backend terminal open).

\`\`\`bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install
\`\`\`

## Running the Application

You need to run both the backend and frontend servers.

### Terminal 1: Start Backend Server

\`\`\`bash
cd backend

# Activate virtual environment if not already active
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Start the Flask server
python server.py
\`\`\`

The backend will start on **http://localhost:5000**

You should see:
\`\`\`
============================================================
🚀 Starting Harivant AI Backend Server
============================================================
API Key configured: ✓
API URL configured: ✓
Model: llama-3.3-70b-versatile
============================================================
Server running on http://localhost:5000
============================================================
\`\`\`

### Terminal 2: Start Frontend Development Server

\`\`\`bash
cd frontend

# Start the Vite dev server
npm run dev
\`\`\`

The frontend will start on **http://localhost:3000** and open automatically in your browser.

## Usage

1. **New Chat**: Click the "New Chat" button in the sidebar
2. **Send Message**: Type your message and press Enter (Shift+Enter for new line)
3. **View History**: Click on previous chats in the sidebar to open them
4. **Delete Chat**: Hover over a chat and click the trash icon
5. **Mobile**: Tap the menu icon to open/close the sidebar

## Installing as PWA

### Desktop (Chrome, Edge, Brave)
1. Open the app in your browser
2. Click the install icon in the address bar
3. Click "Install"

### Mobile (iOS)
1. Open the app in Safari
2. Tap the Share button
3. Tap "Add to Home Screen"

### Mobile (Android)
1. Open the app in Chrome
2. Tap the three dots menu
3. Tap "Add to Home Screen"

## Building for Production

### Frontend

\`\`\`bash
cd frontend
npm run build
\`\`\`

This creates an optimized production build in the `frontend/dist` directory.

### Deployment

#### Frontend
Deploy the `frontend/dist` folder to any static hosting service:
- Vercel
- Netlify
- GitHub Pages
- AWS S3

#### Backend
Deploy the backend to:
- Railway
- Heroku
- AWS EC2
- DigitalOcean
- Google Cloud Run

Make sure to set environment variables on your hosting platform.

## API Configuration

The backend uses environment variables for configuration. Never commit your `.env` file to version control.

### Supported Models

**Groq Models:**
- `llama-3.3-70b-versatile` (Recommended)
- `mixtral-8x7b-32768`
- `gemma2-9b-it`

**OpenAI Models:**
- `gpt-4`
- `gpt-3.5-turbo`
- `gpt-4-turbo`

### Changing Models

Edit the `LLM_MODEL` variable in your `.env` file:

\`\`\`env
LLM_MODEL=llama-3.3-70b-versatile
\`\`\`

Restart the backend server after making changes.

## Troubleshooting

### Backend Issues

**Problem**: `ModuleNotFoundError: No module named 'flask'`

**Solution**: Make sure you activated the virtual environment and installed dependencies:
\`\`\`bash
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
\`\`\`

---

**Problem**: `API credentials not configured`

**Solution**: 
1. Make sure you created a `.env` file in the `backend/` directory
2. Verify your API key is correct
3. Check the API URL matches your provider

---

**Problem**: `CORS error` in browser console

**Solution**: Make sure the backend is running on port 5000 and flask-cors is installed.

---

### Frontend Issues

**Problem**: `Cannot connect to backend`

**Solution**: 
1. Verify the backend is running on http://localhost:5000
2. Check the browser console for errors
3. Make sure CORS is enabled on the backend

---

**Problem**: `Module not found` errors

**Solution**:
\`\`\`bash
rm -rf node_modules package-lock.json
npm install
\`\`\`

---

**Problem**: Chat history not persisting

**Solution**: Check browser localStorage is enabled and not full. Clear browser cache and try again.

## Security Best Practices

1. **Never commit `.env` files** to version control
2. **Use environment variables** for all sensitive data
3. **Rotate API keys** regularly
4. **Use HTTPS** in production
5. **Implement rate limiting** for production deployments
6. **Add authentication** if making the app public

## Features Roadmap

- [ ] Streaming responses for real-time token generation
- [ ] Code syntax highlighting in messages
- [ ] Markdown rendering support
- [ ] Export chat history
- [ ] Dark/Light theme toggle
- [ ] Custom system prompts
- [ ] Multi-model support with switching
- [ ] Voice input
- [ ] Image generation support

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License.

## Support

If you encounter any issues or have questions:

1. Check the troubleshooting section above
2. Review the error messages in the terminal
3. Check browser console for frontend errors
4. Verify your API key and configuration

## Acknowledgments

- Inspired by ChatGPT's interface
- Built with modern web technologies
- Powered by AI (Groq/OpenAI)

---

**Built with ❤️ by the Harivant AI team**
