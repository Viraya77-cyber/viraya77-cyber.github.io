export default function Page() {
  return (
    <div className="min-h-screen bg-[#0f0f0f] text-[#ececec] p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#10a37f" strokeWidth="2">
            <path strokeLinecap="round" strokeLinejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          <h1 className="text-4xl font-bold">Harivant AI</h1>
        </div>

        <div className="bg-[#171717] border border-[#2f2f2f] rounded-xl p-6 mb-6">
          <h2 className="text-2xl font-semibold mb-4 text-[#10a37f]">Production-Ready ChatGPT Clone</h2>
          <p className="text-[#b4b4b4] mb-4">
            This is a complete, standalone application with a React + Vite frontend and Python Flask backend. It
            features ChatGPT-style UI, real-time chat, persistent history, PWA support, and more.
          </p>
          <div className="flex gap-2 flex-wrap">
            <span className="px-3 py-1 bg-[#2f2f2f] rounded-full text-sm">React 18</span>
            <span className="px-3 py-1 bg-[#2f2f2f] rounded-full text-sm">Vite</span>
            <span className="px-3 py-1 bg-[#2f2f2f] rounded-full text-sm">Python Flask</span>
            <span className="px-3 py-1 bg-[#2f2f2f] rounded-full text-sm">PWA</span>
            <span className="px-3 py-1 bg-[#2f2f2f] rounded-full text-sm">LocalStorage</span>
          </div>
        </div>

        <div className="bg-[#171717] border border-[#2f2f2f] rounded-xl p-6 mb-6">
          <h3 className="text-xl font-semibold mb-3">How to Run This Application</h3>
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold text-[#10a37f] mb-2">Step 1: Download the Project</h4>
              <p className="text-[#b4b4b4] text-sm mb-2">
                Click the three dots menu in the top right and select "Download ZIP" to get all project files.
              </p>
            </div>

            <div>
              <h4 className="font-semibold text-[#10a37f] mb-2">Step 2: Get an API Key</h4>
              <p className="text-[#b4b4b4] text-sm mb-2">Choose one option:</p>
              <ul className="list-disc list-inside text-[#b4b4b4] text-sm space-y-1 ml-4">
                <li>
                  <strong>Groq (Free & Fast):</strong>{" "}
                  <a
                    href="https://console.groq.com/keys"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#10a37f] hover:underline"
                  >
                    console.groq.com/keys
                  </a>
                </li>
                <li>
                  <strong>OpenAI:</strong>{" "}
                  <a
                    href="https://platform.openai.com/api-keys"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#10a37f] hover:underline"
                  >
                    platform.openai.com/api-keys
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold text-[#10a37f] mb-2">Step 3: Configure Backend</h4>
              <div className="bg-[#0f0f0f] p-4 rounded-lg text-sm font-mono mb-2">
                <div className="text-[#8e8e8e]"># Navigate to backend directory</div>
                <div>cd backend</div>
                <div className="mt-2 text-[#8e8e8e]"># Create virtual environment</div>
                <div>python -m venv venv</div>
                <div className="mt-2 text-[#8e8e8e]"># Activate it</div>
                <div>source venv/bin/activate</div>
                <div className="mt-2 text-[#8e8e8e]"># Install dependencies</div>
                <div>pip install -r requirements.txt</div>
                <div className="mt-2 text-[#8e8e8e]"># Create .env file from example</div>
                <div>cp .env.example .env</div>
                <div className="mt-2 text-[#8e8e8e]"># Edit .env and add your API key</div>
                <div>nano .env</div>
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-[#10a37f] mb-2">Step 4: Start Backend Server</h4>
              <div className="bg-[#0f0f0f] p-4 rounded-lg text-sm font-mono mb-2">
                <div>python server.py</div>
              </div>
              <p className="text-[#b4b4b4] text-sm">Server will start on http://localhost:5000</p>
            </div>

            <div>
              <h4 className="font-semibold text-[#10a37f] mb-2">Step 5: Start Frontend (New Terminal)</h4>
              <div className="bg-[#0f0f0f] p-4 rounded-lg text-sm font-mono mb-2">
                <div className="text-[#8e8e8e]"># Navigate to frontend directory</div>
                <div>cd frontend</div>
                <div className="mt-2 text-[#8e8e8e]"># Install dependencies</div>
                <div>npm install</div>
                <div className="mt-2 text-[#8e8e8e]"># Start dev server</div>
                <div>npm run dev</div>
              </div>
              <p className="text-[#b4b4b4] text-sm">App will open at http://localhost:3000</p>
            </div>
          </div>
        </div>

        <div className="bg-[#171717] border border-[#2f2f2f] rounded-xl p-6 mb-6">
          <h3 className="text-xl font-semibold mb-3">Features</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div className="flex items-start gap-3">
              <svg
                className="w-5 h-5 text-[#10a37f] flex-shrink-0 mt-0.5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <div>
                <div className="font-semibold">ChatGPT-Style Interface</div>
                <div className="text-[#b4b4b4]">Dark theme with professional design</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <svg
                className="w-5 h-5 text-[#10a37f] flex-shrink-0 mt-0.5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <div>
                <div className="font-semibold">Real-time Chat</div>
                <div className="text-[#b4b4b4]">Powered by Groq or OpenAI</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <svg
                className="w-5 h-5 text-[#10a37f] flex-shrink-0 mt-0.5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <div>
                <div className="font-semibold">Chat History</div>
                <div className="text-[#b4b4b4]">Persistent localStorage storage</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <svg
                className="w-5 h-5 text-[#10a37f] flex-shrink-0 mt-0.5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <div>
                <div className="font-semibold">Fully Responsive</div>
                <div className="text-[#b4b4b4]">Mobile and desktop optimized</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <svg
                className="w-5 h-5 text-[#10a37f] flex-shrink-0 mt-0.5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <div>
                <div className="font-semibold">PWA Support</div>
                <div className="text-[#b4b4b4]">Install as native app</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <svg
                className="w-5 h-5 text-[#10a37f] flex-shrink-0 mt-0.5"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
              <div>
                <div className="font-semibold">Typing Animation</div>
                <div className="text-[#b4b4b4]">Real-time loading indicators</div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-[#171717] border border-[#2f2f2f] rounded-xl p-6 mb-6">
          <h3 className="text-xl font-semibold mb-3">Project Structure</h3>
          <div className="bg-[#0f0f0f] p-4 rounded-lg text-sm font-mono text-[#b4b4b4]">
            <div>harivant-ai/</div>
            <div>
              ├── frontend/ <span className="text-[#8e8e8e]"># React + Vite application</span>
            </div>
            <div>│ ├── src/</div>
            <div>│ │ ├── components/</div>
            <div>│ │ ├── context/</div>
            <div>│ │ └── styles.css</div>
            <div>
              │ ├── public/ <span className="text-[#8e8e8e]"># PWA assets</span>
            </div>
            <div>│ └── package.json</div>
            <div>│</div>
            <div>
              ├── backend/ <span className="text-[#8e8e8e]"># Python Flask API</span>
            </div>
            <div>│ ├── server.py</div>
            <div>│ ├── requirements.txt</div>
            <div>│ └── .env.example</div>
            <div>│</div>
            <div>
              └── README.md <span className="text-[#8e8e8e]"># Full documentation</span>
            </div>
          </div>
        </div>

        <div className="bg-[#2f2f2f] border border-[#3f3f3f] rounded-xl p-6">
          <h3 className="text-xl font-semibold mb-3 flex items-center gap-2">
            <svg className="w-6 h-6 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
            Important Note
          </h3>
          <p className="text-[#b4b4b4] mb-2">
            This is a <strong className="text-[#ececec]">standalone application</strong> that cannot run in this v0
            preview. You need to:
          </p>
          <ol className="list-decimal list-inside text-[#b4b4b4] space-y-1 ml-4">
            <li>Download the ZIP file</li>
            <li>Extract it on your computer</li>
            <li>Follow the setup instructions in README.md</li>
            <li>Run both backend and frontend servers</li>
          </ol>
          <p className="text-[#b4b4b4] mt-3">
            Full documentation is available in the <strong className="text-[#ececec]">README.md</strong> file.
          </p>
        </div>

        <div className="mt-8 text-center text-[#8e8e8e] text-sm">
          <p>Built with React, Vite, Python Flask, and AI</p>
          <p className="mt-1">Ready for production deployment</p>
        </div>
      </div>
    </div>
  )
}
