"use client"

import { createContext, useContext, useState, useEffect } from "react"

const ChatContext = createContext()

export const useChat = () => {
  const context = useContext(ChatContext)
  if (!context) {
    throw new Error("useChat must be used within ChatProvider")
  }
  return context
}

const STORAGE_KEY = "harivant_ai_chats"
const CURRENT_CHAT_KEY = "harivant_ai_current_chat"

// Generate unique ID
const generateId = () => `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`

export const ChatProvider = ({ children }) => {
  const [chats, setChats] = useState([])
  const [currentChatId, setCurrentChatId] = useState(null)
  const [isLoading, setIsLoading] = useState(false)

  // Load chats from localStorage on mount
  useEffect(() => {
    try {
      const savedChats = localStorage.getItem(STORAGE_KEY)
      const savedCurrentId = localStorage.getItem(CURRENT_CHAT_KEY)

      if (savedChats) {
        const parsedChats = JSON.parse(savedChats)
        setChats(parsedChats)

        if (savedCurrentId && parsedChats.find((c) => c.id === savedCurrentId)) {
          setCurrentChatId(savedCurrentId)
        } else if (parsedChats.length > 0) {
          setCurrentChatId(parsedChats[0].id)
        }
      }
    } catch (error) {
      console.error("Error loading chats from localStorage:", error)
    }
  }, [])

  // Save chats to localStorage whenever they change
  useEffect(() => {
    if (chats.length > 0) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(chats))
      } catch (error) {
        console.error("Error saving chats to localStorage:", error)
      }
    }
  }, [chats])

  // Save current chat ID
  useEffect(() => {
    if (currentChatId) {
      try {
        localStorage.setItem(CURRENT_CHAT_KEY, currentChatId)
      } catch (error) {
        console.error("Error saving current chat ID:", error)
      }
    }
  }, [currentChatId])

  // Get current chat
  const currentChat = chats.find((chat) => chat.id === currentChatId)

  // Create new chat
  const createNewChat = () => {
    const newChat = {
      id: generateId(),
      title: "New Chat",
      messages: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    setChats((prev) => [newChat, ...prev])
    setCurrentChatId(newChat.id)
    return newChat.id
  }

  // Send message
  const sendMessage = async (content) => {
    if (!content.trim() || isLoading) return

    let chatId = currentChatId

    // Create new chat if none exists
    if (!chatId) {
      chatId = createNewChat()
    }

    // Add user message
    const userMessage = {
      id: generateId(),
      role: "user",
      content: content.trim(),
      timestamp: new Date().toISOString(),
    }

    setChats((prev) =>
      prev.map((chat) => {
        if (chat.id === chatId) {
          const updatedMessages = [...chat.messages, userMessage]
          return {
            ...chat,
            messages: updatedMessages,
            title: updatedMessages.length === 1 ? content.trim().slice(0, 50) : chat.title,
            updatedAt: new Date().toISOString(),
          }
        }
        return chat
      }),
    )

    setIsLoading(true)

    try {
      // Prepare messages for API
      const chat = chats.find((c) => c.id === chatId) || { messages: [] }
      const allMessages = [
        {
          role: "system",
          content:
            "You are Harivant AI, a helpful, intelligent, and friendly AI assistant. Provide clear, accurate, and helpful responses.",
        },
        ...chat.messages.map((m) => ({ role: m.role, content: m.content })),
        { role: "user", content: content.trim() },
      ]

      // Call backend API
      const response = await fetch("http://localhost:5000/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ messages: allMessages }),
      })

      const data = await response.json()

      if (data.success) {
        // Add assistant message
        const assistantMessage = {
          id: generateId(),
          role: "assistant",
          content: data.message,
          timestamp: new Date().toISOString(),
        }

        setChats((prev) =>
          prev.map((chat) => {
            if (chat.id === chatId) {
              return {
                ...chat,
                messages: [...chat.messages, assistantMessage],
                updatedAt: new Date().toISOString(),
              }
            }
            return chat
          }),
        )
      } else {
        throw new Error(data.error || "Failed to get response")
      }
    } catch (error) {
      console.error("Error sending message:", error)

      // Add error message
      const errorMessage = {
        id: generateId(),
        role: "assistant",
        content: `Sorry, I encountered an error: ${error.message}. Please make sure the backend server is running and configured properly.`,
        timestamp: new Date().toISOString(),
        isError: true,
      }

      setChats((prev) =>
        prev.map((chat) => {
          if (chat.id === chatId) {
            return {
              ...chat,
              messages: [...chat.messages, errorMessage],
              updatedAt: new Date().toISOString(),
            }
          }
          return chat
        }),
      )
    } finally {
      setIsLoading(false)
    }
  }

  // Switch to different chat
  const switchChat = (chatId) => {
    setCurrentChatId(chatId)
  }

  // Delete chat
  const deleteChat = (chatId) => {
    setChats((prev) => {
      const filtered = prev.filter((chat) => chat.id !== chatId)

      // If deleting current chat, switch to another
      if (chatId === currentChatId) {
        setCurrentChatId(filtered.length > 0 ? filtered[0].id : null)
      }

      // Clear localStorage if no chats left
      if (filtered.length === 0) {
        localStorage.removeItem(STORAGE_KEY)
        localStorage.removeItem(CURRENT_CHAT_KEY)
      }

      return filtered
    })
  }

  const value = {
    chats,
    currentChat,
    currentChatId,
    isLoading,
    createNewChat,
    sendMessage,
    switchChat,
    deleteChat,
  }

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>
}
