"use client"

import { useEffect, useRef } from "react"
import { useChat } from "../context/ChatContext"
import Message from "./Message"

const ChatArea = ({ onMenuClick, isMobile }) => {
  const { currentChat, isLoading } = useChat()
  const messagesEndRef = useRef(null)
  const chatContainerRef = useRef(null)

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" })
    }
  }, [currentChat?.messages, isLoading])

  return (
    <div className="chat-area" ref={chatContainerRef}>
      {isMobile && (
        <div className="mobile-header">
          <button className="menu-btn" onClick={onMenuClick}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
          <h2>Harivant AI</h2>
        </div>
      )}

      <div className="messages-container">
        {!currentChat || currentChat.messages.length === 0 ? (
          <div className="welcome-screen">
            <div className="welcome-content">
              <div className="welcome-icon">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h2>Welcome to Harivant AI</h2>
              <p>Your intelligent AI assistant, ready to help with any question or task.</p>
              <div className="example-prompts">
                <span className="example-label">Try asking:</span>
                <div className="example-grid">
                  <div className="example-card">Explain quantum computing</div>
                  <div className="example-card">Write a Python function</div>
                  <div className="example-card">Plan a trip to Japan</div>
                  <div className="example-card">Help me debug my code</div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <>
            {currentChat.messages.map((message) => (
              <Message key={message.id} message={message} />
            ))}
            {isLoading && (
              <div className="message assistant">
                <div className="message-avatar">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <div className="message-content">
                  <div className="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </>
        )}
      </div>
    </div>
  )
}

export default ChatArea
