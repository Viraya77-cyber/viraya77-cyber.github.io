"use client"

import { useState, useEffect } from "react"
import Sidebar from "./components/Sidebar"
import ChatArea from "./components/ChatArea"
import InputBar from "./components/InputBar"
import { ChatProvider } from "./context/ChatContext"
import "./styles.css"

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768)

  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768
      setIsMobile(mobile)
      if (mobile) {
        setIsSidebarOpen(false)
      } else {
        setIsSidebarOpen(true)
      }
    }

    window.addEventListener("resize", handleResize)
    handleResize()

    return () => window.removeEventListener("resize", handleResize)
  }, [])

  return (
    <ChatProvider>
      <div className="app">
        <Sidebar isOpen={isSidebarOpen} onClose={() => setIsSidebarOpen(false)} isMobile={isMobile} />
        <div className="main-content">
          <ChatArea onMenuClick={() => setIsSidebarOpen(!isSidebarOpen)} isMobile={isMobile} />
          <InputBar />
        </div>
        {isMobile && isSidebarOpen && <div className="sidebar-overlay" onClick={() => setIsSidebarOpen(false)} />}
      </div>
    </ChatProvider>
  )
}

export default App
