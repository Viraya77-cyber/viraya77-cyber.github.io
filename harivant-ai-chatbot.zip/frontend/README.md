# Harivant AI Frontend

React-based frontend for Harivant AI chat application.

## Quick Start

\`\`\`bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
\`\`\`

## Environment

The frontend expects the backend API to be running at `http://localhost:5000`.

To change this, update the API URL in `src/context/ChatContext.jsx`:

\`\`\`javascript
const response = await fetch("http://localhost:5000/chat", {
  // ...
})
\`\`\`

## Features

- ChatGPT-style interface
- Dark theme
- Responsive design (mobile + desktop)
- Chat history with localStorage
- PWA support with offline capabilities
- Smooth animations and transitions

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## PWA Features

The app is installable as a Progressive Web App with:
- Offline support via service worker
- App icons for home screen
- Standalone display mode
- Fast loading and caching
