"""
Harivant AI - Backend API Server
---------------------------------
This server handles chat requests and interfaces with LLM providers (Groq, OpenAI, etc.)
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from dotenv import load_dotenv
import requests
import time

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
# Enable CORS for all routes (allows frontend to communicate with backend)
CORS(app)

# ============================================================
# ENVIRONMENT VARIABLES - REPLACE IN .env FILE
# ============================================================
LLM_API_URL = os.getenv('LLM_API_URL', '')
LLM_API_KEY = os.getenv('LLM_API_KEY', '')
LLM_MODEL = os.getenv('LLM_MODEL', 'llama-3.3-70b-versatile')  # Default Groq model

# Validate that API credentials are set
if not LLM_API_KEY:
    print("⚠️  WARNING: LLM_API_KEY is not set in environment variables!")
    print("   Please create a .env file with your API key.")
    print("   Example: LLM_API_KEY=your_api_key_here")

if not LLM_API_URL:
    print("⚠️  WARNING: LLM_API_URL is not set in environment variables!")
    print("   Please create a .env file with your API URL.")
    print("   Example: LLM_API_URL=https://api.groq.com/openai/v1/chat/completions")


def call_llm_api(messages):
    """
    Call the LLM API (Groq, OpenAI, or compatible provider)
    
    Args:
        messages: List of message objects with 'role' and 'content'
        
    Returns:
        dict: Response from LLM or error message
    """
    
    # Check if API credentials are configured
    if not LLM_API_KEY or not LLM_API_URL:
        return {
            'success': False,
            'error': 'API credentials not configured. Please set LLM_API_KEY and LLM_API_URL in .env file.'
        }
    
    # Prepare headers with API key
    headers = {
        'Authorization': f'Bearer {LLM_API_KEY}',
        'Content-Type': 'application/json'
    }
    
    # Prepare request payload (OpenAI-compatible format)
    payload = {
        'model': LLM_MODEL,
        'messages': messages,
        'temperature': 0.7,
        'max_tokens': 2000,
        'stream': False  # Non-streaming for simplicity
    }
    
    try:
        # Make API request with timeout
        response = requests.post(
            LLM_API_URL,
            headers=headers,
            json=payload,
            timeout=30  # 30 second timeout
        )
        
        # Check if request was successful
        if response.status_code == 200:
            data = response.json()
            
            # Extract assistant message from response
            if 'choices' in data and len(data['choices']) > 0:
                assistant_message = data['choices'][0]['message']['content']
                return {
                    'success': True,
                    'message': assistant_message
                }
            else:
                return {
                    'success': False,
                    'error': 'Unexpected response format from LLM API'
                }
        else:
            # API returned an error
            error_message = f"API Error {response.status_code}"
            try:
                error_data = response.json()
                if 'error' in error_data:
                    error_message = error_data['error'].get('message', error_message)
            except:
                pass
                
            return {
                'success': False,
                'error': error_message
            }
            
    except requests.exceptions.Timeout:
        return {
            'success': False,
            'error': 'Request timed out. Please try again.'
        }
    except requests.exceptions.ConnectionError:
        return {
            'success': False,
            'error': 'Could not connect to LLM API. Please check your internet connection.'
        }
    except Exception as e:
        return {
            'success': False,
            'error': f'Unexpected error: {str(e)}'
        }


@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint to verify server is running"""
    return jsonify({
        'status': 'healthy',
        'message': 'Harivant AI Backend is running',
        'api_configured': bool(LLM_API_KEY and LLM_API_URL)
    })


@app.route('/chat', methods=['POST'])
def chat():
    """
    Main chat endpoint
    
    Expects JSON body:
    {
        "messages": [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Hello!"}
        ]
    }
    
    Returns:
    {
        "success": true,
        "message": "Hello! How can I help you today?"
    }
    """
    
    try:
        # Parse request body
        data = request.get_json()
        
        if not data or 'messages' not in data:
            return jsonify({
                'success': False,
                'error': 'Missing "messages" in request body'
            }), 400
        
        messages = data['messages']
        
        # Validate messages format
        if not isinstance(messages, list) or len(messages) == 0:
            return jsonify({
                'success': False,
                'error': 'Messages must be a non-empty array'
            }), 400
        
        # Call LLM API
        result = call_llm_api(messages)
        
        if result['success']:
            return jsonify({
                'success': True,
                'message': result['message']
            })
        else:
            return jsonify({
                'success': False,
                'error': result['error']
            }), 500
            
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f'Server error: {str(e)}'
        }), 500


if __name__ == '__main__':
    print("=" * 60)
    print("🚀 Starting Harivant AI Backend Server")
    print("=" * 60)
    print(f"API Key configured: {'✓' if LLM_API_KEY else '✗'}")
    print(f"API URL configured: {'✓' if LLM_API_URL else '✗'}")
    print(f"Model: {LLM_MODEL}")
    print("=" * 60)
    print("Server running on http://localhost:5000")
    print("=" * 60)
    
    # Run Flask development server
    app.run(host='0.0.0.0', port=5000, debug=True)
