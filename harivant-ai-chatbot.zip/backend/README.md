# Harivant AI Backend

Python Flask backend for Harivant AI chat application.

## Quick Start

\`\`\`bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Create .env file
cp .env.example .env

# Edit .env and add your API credentials
nano .env

# Run server
python server.py
\`\`\`

## API Endpoints

### Health Check

\`\`\`
GET /health
\`\`\`

Returns server status and configuration.

**Response:**
\`\`\`json
{
  "status": "healthy",
  "message": "Harivant AI Backend is running",
  "api_configured": true
}
\`\`\`

### Chat

\`\`\`
POST /chat
\`\`\`

Send a chat message and receive AI response.

**Request Body:**
\`\`\`json
{
  "messages": [
    {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": "Hello!"}
  ]
}
\`\`\`

**Response:**
\`\`\`json
{
  "success": true,
  "message": "Hello! How can I help you today?"
}
\`\`\`

**Error Response:**
\`\`\`json
{
  "success": false,
  "error": "Error message here"
}
\`\`\`

## Environment Variables

See `.env.example` for all available configuration options.

Required variables:
- `LLM_API_URL` - API endpoint URL
- `LLM_API_KEY` - API key for authentication
- `LLM_MODEL` - Model to use (optional, has default)

## Error Handling

The backend gracefully handles:
- Missing API credentials
- Network errors
- API timeouts (30 seconds)
- Invalid request formats
- Rate limits

## Security

- API keys stored in environment variables
- CORS enabled for frontend communication
- Input validation on all endpoints
- Timeout protection on API calls
